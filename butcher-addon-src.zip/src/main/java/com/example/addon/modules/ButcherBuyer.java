package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.ingame.MerchantScreen;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.MerchantScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.VillagerProfession;

import java.util.Comparator;
import java.util.List;

public class ButcherBuyer extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgItems   = settings.createGroup("Товары");

    // ── Настройки ──────────────────────────────────────────────────────────

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("радиус-поиска")
        .description("Дальность поиска жителей-мясников")
        .defaultValue(16.0).min(2.0).max(64.0).sliderMax(32.0)
        .build());

    private final Setting<Integer> tickDelay = sgGeneral.add(new IntSetting.Builder()
        .name("задержка-тики")
        .description("Тики между действиями (1 тик = 50 мс)")
        .defaultValue(4).min(1).max(40)
        .build());

    private final Setting<Integer> buyLimit = sgGeneral.add(new IntSetting.Builder()
        .name("лимит-стаков")
        .description("Максимум покупок за одно открытие торгов (0 = без лимита)")
        .defaultValue(0).min(0).max(64)
        .build());

    private final Setting<Boolean> useWalk = sgGeneral.add(new BoolSetting.Builder()
        .name("ходьба-к-жителю")
        .description("Идти к жителю (ON = +W симуляция, OFF = телепортация пакетом)")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> chatLog = sgGeneral.add(new BoolSetting.Builder()
        .name("лог-в-чат")
        .description("Писать в чат что куплено")
        .defaultValue(true)
        .build());

    // Что покупать
    private final Setting<Boolean> buySteak = sgItems.add(new BoolSetting.Builder()
        .name("стейк").defaultValue(true).build());
    private final Setting<Boolean> buyPork = sgItems.add(new BoolSetting.Builder()
        .name("жареная-свинина").defaultValue(true).build());
    private final Setting<Boolean> buyChicken = sgItems.add(new BoolSetting.Builder()
        .name("жареная-курица").defaultValue(true).build());
    private final Setting<Boolean> buyMutton = sgItems.add(new BoolSetting.Builder()
        .name("жареная-баранина").defaultValue(true).build());
    private final Setting<Boolean> buyRabbit = sgItems.add(new BoolSetting.Builder()
        .name("жареная-крольчатина").defaultValue(true).build());

    // ── Состояние ──────────────────────────────────────────────────────────

    private VillagerEntity targetVillager = null;
    private int timer = 0;
    private int boughtThisSession = 0;
    private int totalBought = 0;
    private State state = State.SEARCHING;

    private enum State { SEARCHING, WALKING, TRADING, COOLDOWN }

    // ── Имена предметов для лога ───────────────────────────────────────────

    private static final java.util.Map<Item, String> ITEM_NAMES = new java.util.HashMap<>();
    static {
        ITEM_NAMES.put(Items.COOKED_BEEF,     "Стейк");
        ITEM_NAMES.put(Items.COOKED_PORKCHOP, "Жареная свинина");
        ITEM_NAMES.put(Items.COOKED_CHICKEN,  "Жареная курица");
        ITEM_NAMES.put(Items.COOKED_MUTTON,   "Жареная баранина");
        ITEM_NAMES.put(Items.COOKED_RABBIT,   "Жареная крольчатина");
    }

    public ButcherBuyer() {
        super(AddonTemplate.CATEGORY, "butcher-buyer",
            "Авто-покупка еды у жителей-мясников");
    }

    @Override
    public void onActivate() {
        targetVillager = null;
        boughtThisSession = 0;
        totalBought = 0;
        timer = 0;
        state = State.SEARCHING;
        info("ButcherBuyer запущен. Ищу мясников в радиусе §e" + range.get().intValue() + " блоков§r...");
    }

    @Override
    public void onDeactivate() {
        stopWalking();
        if (mc.player != null && mc.player.currentScreenHandler instanceof MerchantScreenHandler) {
            mc.player.closeHandledScreen();
        }
        info("ButcherBuyer остановлен. Всего куплено за сессию: §a" + totalBought + "§r предметов.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        timer++;
        if (timer < tickDelay.get()) return;
        timer = 0;

        switch (state) {
            case SEARCHING -> handleSearching();
            case WALKING   -> handleWalking();
            case TRADING   -> handleTrading();
            case COOLDOWN  -> { state = State.SEARCHING; }
        }
    }

    // ── Поиск ────────────────────────────────────────────────────────────

    private void handleSearching() {
        // Если уже открыто окно — сразу к торговле
        if (mc.player.currentScreenHandler instanceof MerchantScreenHandler) {
            boughtThisSession = 0;
            state = State.TRADING;
            return;
        }

        targetVillager = findNearestButcher();
        if (targetVillager == null) {
            // Нет мясников поблизости — ждём
            return;
        }

        double dist = mc.player.squaredDistanceTo(targetVillager);
        if (dist <= 9.0) { // 3 блока
            interactVillager();
            state = State.TRADING;
        } else {
            state = State.WALKING;
        }
    }

    // ── Ходьба ────────────────────────────────────────────────────────────

    private void handleWalking() {
        if (targetVillager == null || !targetVillager.isAlive()) {
            state = State.SEARCHING;
            stopWalking();
            return;
        }

        double dist = mc.player.squaredDistanceTo(targetVillager);

        if (dist <= 9.0) {
            stopWalking();
            interactVillager();
            state = State.TRADING;
            return;
        }

        if (useWalk.get()) {
            // Поворачиваем к жителю и зажимаем W
            double dx = targetVillager.getX() - mc.player.getX();
            double dz = targetVillager.getZ() - mc.player.getZ();
            float yaw = (float)(Math.toDegrees(Math.atan2(-dx, dz)));
            mc.player.setYaw(yaw);
            mc.player.input.movementForward = 1.0f;
        } else {
            // Телепорт (только в одиночной / если есть права)
            mc.player.setPosition(
                targetVillager.getX(),
                targetVillager.getY(),
                targetVillager.getZ() - 1.5
            );
        }
    }

    private void stopWalking() {
        if (mc.player == null) return;
        mc.player.input.movementForward = 0.0f;
    }

    // ── Торговля ──────────────────────────────────────────────────────────

    private void handleTrading() {
        if (!(mc.player.currentScreenHandler instanceof MerchantScreenHandler merchant)) {
            // Окно закрылось
            state = State.COOLDOWN;
            targetVillager = null;
            return;
        }

        List<TradeOffer> offers = merchant.getRecipes();
        int limit = buyLimit.get();

        for (int i = 0; i < offers.size(); i++) {
            TradeOffer offer = offers.get(i);
            if (offer.isDisabled()) continue;

            Item result = offer.getSellItem().getItem();
            if (!isWanted(result)) continue;

            if (limit > 0 && boughtThisSession >= limit) {
                mc.player.closeHandledScreen();
                state = State.SEARCHING;
                return;
            }

            // Выбираем оффер (клик по слоту в списке)
            mc.interactionManager.clickSlot(
                merchant.syncId, i, 0, SlotActionType.PICKUP, mc.player);

            // Берём результат из слота вывода (slot 2)
            mc.interactionManager.clickSlot(
                merchant.syncId, 2, 0, SlotActionType.PICKUP, mc.player);

            boughtThisSession++;
            totalBought++;

            if (chatLog.get()) {
                String name = ITEM_NAMES.getOrDefault(result, result.toString());
                info("Куплено: §a" + name + "§r (всего: " + totalBought + ")");
            }
            return; // один предмет за тик
        }

        // Все доступные офферы куплены
        mc.player.closeHandledScreen();
        state = State.SEARCHING;
        targetVillager = null;
    }

    // ── Утилиты ───────────────────────────────────────────────────────────

    private boolean isWanted(Item item) {
        if (item == Items.COOKED_BEEF     && buySteak.get())   return true;
        if (item == Items.COOKED_PORKCHOP && buyPork.get())    return true;
        if (item == Items.COOKED_CHICKEN  && buyChicken.get()) return true;
        if (item == Items.COOKED_MUTTON   && buyMutton.get())  return true;
        if (item == Items.COOKED_RABBIT   && buyRabbit.get())  return true;
        return false;
    }

    private VillagerEntity findNearestButcher() {
        return mc.world.getEntitiesByClass(
            VillagerEntity.class,
            mc.player.getBoundingBox().expand(range.get()),
            v -> v.getVillagerData().getProfession() == VillagerProfession.BUTCHER
        ).stream()
         .filter(v -> !v.isDead())
         .min(Comparator.comparingDouble(v -> mc.player.squaredDistanceTo(v)))
         .orElse(null);
    }

    private void interactVillager() {
        if (targetVillager == null) return;
        mc.interactionManager.interactEntity(mc.player, targetVillager, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    @Override
    public String getInfoString() {
        return "Куплено: " + totalBought + " | " + state.name();
    }
}
